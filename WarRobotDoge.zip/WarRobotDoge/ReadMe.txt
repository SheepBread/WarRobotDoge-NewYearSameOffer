The extension "odt" comes from LibreOffice. It may or may not be compatible or carry over all article features
to Microsoft Word. I suspect that at the most- it'll just displace the pictures.

If you don't have a way to view this file:

https://www.libreoffice.org/download/download-libreoffice/

or

https://www.openoffice.org/

or maybe even Microsoft Word Online would work. I've provided a PDF and HTML version as well. The PDF better
preserves my picture placement. Though- I wasn't really designing for a website- since this was in a word
processor. Feel free to take liberties with font style, size, picture adjustments, flair, etc. I'm not able
to send a lightning bolt through your window- as of yet- so you have little to fear about "ruining" the article.

I've provided the images in their own seperate folder- if grabbing them from these article files and then 
resizing them proves problematic considering how optimizing compression might have taken place when they were 
resized in the article. I know this used to be a problem in Microsoft Word years ago.

I suggest you actually read what I've put up- in case I say something crazy from your view; such as Barney
the dinosaur being our center mass of the solar system- as our doughnut shaped earth twirls around it (not in
an eclipse, but a perfect square orbit.) I've reread it three times, but the mind skips over things- so if I
say a word twice, like "the the" feel free to correct it.

Ideally, I would (look at this error -->) ususally review my documents and perform minor adjustments as I mentally
review them in my day. But this artilce is timely, and I won't harrass you for 400 minor adjustments later- 
each made 20 minutes apart right after you finialize placement of things.

Lord bless you for taking the time- and placeing yourself ready for persecution. My anxiety would cause a
heart attack- as the public eye is unending and contains the darkest of perceptions, attacking from all angles.